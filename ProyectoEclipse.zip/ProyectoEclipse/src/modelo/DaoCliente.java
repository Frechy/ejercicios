package modelo;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DaoCliente {

	
	private Connection con = null;

	private static DaoCliente instance = null;

	private DaoCliente() throws SQLException {
		con = DBConnection.getConnection();
	}

	public static DaoCliente getInstance() throws SQLException {
		if (instance == null)
			instance = new DaoCliente();

		return instance;
	}
	
	
	/**
	 * 
	 * Metodo que inserta mediante el conector JDBC los datos de un cliente en la Base de datos
	 * 
	 * @param t
	 * @throws SQLException
	 */
	public void insert(Cliente t) throws SQLException {

		PreparedStatement ps = con.prepareStatement(
				"INSERT INTO clientes(dni, nombre, apellidos, nombreVia, numero, piso, puerta, cp, provincia, poblacion, pais, tipoVia) VALUES (?, ?, ?, ?, ?, ?, ?, ?,?,?,?,?)");
		ps.setString(1, t.getDni());
		ps.setString(2, t.getNombre());
		ps.setString(3, t.getApellidos());
		ps.setString(4, t.getNombreVia());
		ps.setInt(5, t.getNumero());
		ps.setInt(6, t.getPiso());
		ps.setString(7,t.getPuerta());
		ps.setString(8,t.getCp());
		ps.setString(9,t.getProvincia());
		ps.setString(10,t.getPoblacion());
		ps.setString(11,t.getPais());
		ps.setInt(12, t.getTipoVia());
		
		ps.executeUpdate();

		ps.close();

	}
	
	
	
	/**
	 *  Metodo que acutaliza los datos de un cliente mediante el id almacenado del mismo.
	 * @param t
	 * @throws SQLException
	 */
	public void update(Cliente t) throws SQLException {

		if (t.getId() != 0) {
			
		PreparedStatement ps = con.prepareStatement(
				"UPDATE clientes SET dni = ?, nombre = ?, apellidos = ?, nombreVia = ?, numero = ?, piso = ?, puerta = ?, cp = ?, provincia = ?, poblacion = ?, pais = ?, tipoVia = ? WHERE id = ?");
				
		ps.setString(1, t.getDni());
		ps.setString(2, t.getNombre());
		ps.setString(3, t.getApellidos());
		ps.setString(4, t.getNombreVia());
		ps.setInt(5, t.getNumero());
		ps.setInt(6, t.getPiso());
		ps.setString(7,t.getPuerta());
		ps.setString(8,t.getCp());
		ps.setString(9,t.getProvincia());
		ps.setString(10,t.getPoblacion());
		ps.setString(11,t.getPais());
		ps.setInt(12, t.getTipoVia());
		ps.setInt(13, t.getId());
		
		ps.executeUpdate();
		
		ps.close();
		
		}

	} 
	
	
	
	/**
	 * Metodo que retorna la lista de clientes almacenados en la base de datos. 
	 * @return
	 * @throws SQLException
	 */
	public List<Cliente> obtenerLista() throws SQLException {

		PreparedStatement ps = con.prepareStatement("SELECT * FROM clientes");
		ResultSet rs = ps.executeQuery();

		List<Cliente> result = null;

		while (rs.next()) {
			if (result == null)
				result = new ArrayList<>();

			result.add(new Cliente(rs.getInt("id"),  rs.getString("dni"),rs.getString("nombre"), rs.getString("apellidos"), rs.getString("nombreVia"), rs.getInt("numero"), rs.getInt("piso"),
					rs.getString("puerta"), rs.getString("cp"), rs.getString("provincia"), rs.getString("poblacion"),rs.getString("pais"), rs.getInt("tipoVia")));
		}

		rs.close();
		ps.close();

		return result;
	}
	
	/*
	 * Metodo que obtiene los datos de un cliente por medio de la identificación del ID
	 */
	public Cliente obtenerPorId(int id) throws SQLException {

		PreparedStatement ps = con.prepareStatement("SELECT * FROM clientes WHERE id = ?");
		ps.setInt(1, id);
		ResultSet rs = ps.executeQuery();

		Cliente result = null;

		if (rs.next()) {
			result = new Cliente(rs.getInt("id"),  rs.getString("dni"),rs.getString("nombre"), rs.getString("apellidos"), rs.getString("nombreVia"), rs.getInt("numero"), rs.getInt("piso"),
					rs.getString("puerta"), rs.getString("cp"), rs.getString("provincia"), rs.getString("poblacion"),rs.getString("pais"), rs.getInt("tipoVia"));

		}
		rs.close();
		ps.close();

		return result;

	
	
	}
	
	/**
	 * Metodo para borrar un cliente de la base de datos proporciandole el id del mismo.
	 * @param id
	 * @throws SQLException
	 */
public void delete(int id) throws SQLException {
		
		if (id <= 0)
			return;
		
		PreparedStatement ps = con.prepareStatement("DELETE FROM Clientes WHERE id = ?");
		ps.setInt(1, id);

		ps.executeUpdate();

		ps.close();
	}
	
	
	
}
