package modelo;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Cliente {
		private int id;
	    private String dni;
	    private String nombre;
	    private String apellidos;
	    private String nombreVia;
	    private int numero;
	    private int piso;
	    private String puerta;
	    private String cp;
	    private String provincia;
	    private String poblacion;
	    private String pais;
	    private int tipoVia;

	    
	    /**
	     * Constructor Cliente Vacio
	     */
	    public Cliente() {
	    }

	    
	    /**
	     * Constructor con parametros
	     * 
	     * @param id
	     * @param dni
	     * @param nombre
	     * @param apellidos
	     * @param nombreVia
	     * @param numero
	     * @param piso
	     * @param puerta
	     * @param cp
	     * @param provincia
	     * @param poblacion
	     * @param pais
	     * @param tipoVia
	     */
	    
	    public Cliente(int id, String dni, String nombre, String apellidos, String nombreVia, int numero, int piso, String puerta, String cp, String provincia, String poblacion, String pais, int tipoVia) {
	        this.id = id;
	        this.dni = dni;
	        this.nombre = nombre;
	        this.apellidos = apellidos;
	        this.nombreVia = nombreVia;
	        this.numero = numero;
	        this.piso = piso;
	        this.puerta = puerta;
	        this.cp = cp;
	        this.provincia = provincia;
	        this.poblacion = poblacion;
	        this.pais = pais;
	        this.tipoVia = tipoVia;
	    }

	    public int getId() {
	        return id;
	    }

	    public void setId(int id) {
	        this.id = id;
	    }

	    public String getDni() {
	        return dni;
	    }

	    public void setDni(String dni) {
	        this.dni = dni;
	    }

	    public String getNombre() {
	        return nombre;
	    }

	    public void setNombre(String nombre) {
	        this.nombre = nombre;
	    }

	    public String getApellidos() {
	        return apellidos;
	    }

	    public void setApellidos(String apellidos) {
	        this.apellidos = apellidos;
	    }

	    public String getNombreVia() {
	        return nombreVia;
	    }

	    public void setNombreVia(String nombreVia) {
	        this.nombreVia = nombreVia;
	    }


	    public int getNumero() {
	        return numero;
	    }

	    public void setNumero(int numero) {
	        this.numero = numero;
	    }

	    public int getPiso() {
	        return piso;
	    }

	    public void setPiso(int piso) {
	        this.piso = piso;
	    }

	    public String getPuerta() {
	        return puerta;
	    }

	    public void setPuerta(String puerta) {
	        this.puerta = puerta;
	    }

	    public String getCp() {
	        return cp;
	    }

	    public void setCp(String cp) {
	        this.cp = cp;
	    }

	    public String getProvincia() {
	        return provincia;
	    }

	    public void setProvincia(String provincia) {
	        this.provincia = provincia;
	    }

	    public String getPoblacion() {
	        return poblacion;
	    }

	    public void setPoblacion(String poblacion) {
	        this.poblacion = poblacion;
	    }

	    public String getPais() {
	        return pais;
	    }

	    public void setPais(String pais) {
	        this.pais = pais;
	    }
	    
	    
	    
	    public int getTipoVia() {
			return tipoVia;
		}

		public void setTipoVia(int tipoVia) {
			this.tipoVia = tipoVia;
		}

		
		/**
		 * Metodo de inserción de cliente. Envia los datos del objeto al metodo de la clase DAO de insertar.
		 * @throws SQLException
		 */
		
		public void insertar() throws SQLException {
	    	
	    	
	    	DaoCliente.getInstance().insert(this);
	    	
	    }
	    

		/**
		 * Metodo de actualización de cliente. Envia los datos del objeto al metodo de la clase DAO de actualizar.
		 * @throws SQLException
		 */
	    public void update() throws SQLException {
	    	
	    	
	    	DaoCliente.getInstance().update(this);
	    	
	    }
	    

		/**
		 * Metodo de Borrado de cliente. Envia el id del objeto actual al metodo de la clase DAO de borrado.
		 * @throws SQLException
		 */
	    public void delete(int id) throws SQLException {
	    	
	    	
	    	DaoCliente.getInstance().delete(id);
	    	
	    }
	    
	    
	    /**
	     * Metodo para obtener la lista de clientes obtenidos de la base de datos mediante el metodo obtener de la clase DAO
	     * @return
	     * @throws SQLException
	     */
	    
	    public List<Cliente> obtenerLista() throws SQLException{
	    	
	    	
	    	List<Cliente> lista = DaoCliente.getInstance().obtenerLista();
	    	
	    	return lista;
	    }
	    

}
