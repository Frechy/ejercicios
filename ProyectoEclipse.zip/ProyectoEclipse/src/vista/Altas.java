package vista;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JTextField;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.Font;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.table.DefaultTableModel;

import modelo.Cliente;
import modelo.DaoCliente;

import java.awt.GridLayout;
import java.awt.List;

import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.border.LineBorder;
import java.awt.Color;
import javax.swing.ListSelectionModel;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Altas  {

	private JFrame frame;
	private JTextField textField_nombreVia;
	private JTextField textField_nombre;
	private JTextField textField_apellidos;
	private JTextField textField_dni;
	private JTextField textField_numero;
	private JTextField textField_piso;
	private JTextField textField_puerta;
	private JTextField textField_cp;
	private JTextField textField_poblacion;
	private JTextField textField_provincia;
	private JTextField textField_pais;
	private JComboBox  comboTipovia;
	private JTable table;
	private Cliente cliente;
	

	/**
	 * Launch the application.
	 */
	
	/*
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Altas window = new Altas();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
*/
	/**
	 * Create the application.
	 * @throws SQLException 
	 */
	public Altas() throws SQLException {
		
		cliente = new Cliente();
		initialize();
	}
	
	

	public JFrame getFrame() {
		return frame;
	}



	public void setFrame(JFrame frame) {
		this.frame = frame;
	}



	/**
	 * MEtodo de inicalización de la interfaz gráfica. 
	 * 
	 * @throws SQLException 
	 */
	private void initialize() throws SQLException {
		frame = new JFrame();
		frame.setBounds(100, 100, 620, 427);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JPanel panel = new JPanel();
		
		JPanel panel_1 = new JPanel();
		
		JScrollPane scrollPane = new JScrollPane();
		GroupLayout groupLayout = new GroupLayout(frame.getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addComponent(panel_1, GroupLayout.DEFAULT_SIZE, 618, Short.MAX_VALUE)
						.addComponent(panel, GroupLayout.PREFERRED_SIZE, 618, GroupLayout.PREFERRED_SIZE)
						.addGroup(groupLayout.createSequentialGroup()
							.addContainerGap()
							.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 608, Short.MAX_VALUE)))
					.addContainerGap())
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addComponent(panel, GroupLayout.PREFERRED_SIZE, 105, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(panel_1, GroupLayout.PREFERRED_SIZE, 40, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 242, Short.MAX_VALUE)
					.addContainerGap())
		);
		
		
		
		DefaultTableModel modelo = new DefaultTableModel();
		table = new JTable(modelo);
		

		table.setSurrendersFocusOnKeystroke(true);
		table.addMouseListener(new MouseAdapter() {
			
			
			
			
			@Override
			public void mouseClicked(MouseEvent e) {
			
				llenarCampos();
				
				
				
				
				
			}
		});
		table.setFillsViewportHeight(true);
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		table.setBorder(new LineBorder(new Color(0, 0, 0), 1, true));
	
	
		
		scrollPane.setViewportView(table);
		panel_1.setLayout(new GridLayout(1, 0, 0, 0));
		
		this.pintarTabla();
		
	
	
		
		
		// Boton guardar cliente
		JButton btnGuardar = new JButton("Guardar");
		btnGuardar.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
				
				guardado();
			
			}
		});
		panel_1.add(btnGuardar);
		
		JButton btnBorrar = new JButton("Borrar");
		btnBorrar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
			borrado();
			}
		});
		btnBorrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnBorrar.setEnabled(true);
		panel_1.add(btnBorrar);
		
		JButton btnLimpiar = new JButton("Limpiar");
		btnLimpiar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				limpiarCampos();
			}
		});
		panel_1.add(btnLimpiar);
		
		JLabel lblNombre = new JLabel("Nombre:");
		lblNombre.setFont(new Font("Lucida Grande", Font.PLAIN, 10));
		panel.add(lblNombre);
		
		textField_nombre = new JTextField();
		panel.add(textField_nombre);
		textField_nombre.setColumns(10);
		
		JLabel lblApellidos = new JLabel("Apellidos:");
		lblApellidos.setFont(new Font("Lucida Grande", Font.PLAIN, 10));
		panel.add(lblApellidos);
		
		textField_apellidos = new JTextField();
		panel.add(textField_apellidos);
		textField_apellidos.setColumns(15);
		
		JLabel lblDni = new JLabel("DNI:");
		lblDni.setFont(new Font("Lucida Grande", Font.PLAIN, 10));
		panel.add(lblDni);
		
		textField_dni = new JTextField();
		panel.add(textField_dni);
		textField_dni.setColumns(10);
		
		JLabel lblTipoVia = new JLabel("Tipo Via");
		lblTipoVia.setFont(new Font("Lucida Grande", Font.PLAIN, 10));
		panel.add(lblTipoVia);
		
		comboTipovia = new JComboBox();
		comboTipovia.setFont(new Font("Lucida Console", Font.PLAIN, 10));
		comboTipovia.setModel(new DefaultComboBoxModel(new String[] {"...","Calle", "Plaza", "Avenida"}));
		panel.add(comboTipovia);
		
		JLabel lblNombreVa = new JLabel("Nombre Vía:");
		lblNombreVa.setFont(new Font("Lucida Grande", Font.PLAIN, 10));
		panel.add(lblNombreVa);
		
		textField_nombreVia = new JTextField();
		panel.add(textField_nombreVia);
		textField_nombreVia.setColumns(10);
		
		JLabel lblN = new JLabel("Nº");
		lblN.setFont(new Font("Lucida Grande", Font.PLAIN, 10));
		panel.add(lblN);
		
		textField_numero = new JTextField();
		textField_numero.setText("0");
		panel.add(textField_numero);
		textField_numero.setColumns(4);
		
		JLabel lblPiso = new JLabel("Piso");
		lblPiso.setFont(new Font("Lucida Grande", Font.PLAIN, 10));
		panel.add(lblPiso);
		
		textField_piso = new JTextField();
		textField_piso.setText("0");
		panel.add(textField_piso);
		textField_piso.setColumns(3);
		
		JLabel lblPuerta = new JLabel("Puerta:");
		lblPuerta.setFont(new Font("Lucida Grande", Font.PLAIN, 10));
		panel.add(lblPuerta);
		
		textField_puerta = new JTextField();
		panel.add(textField_puerta);
		textField_puerta.setColumns(4);
		
		JLabel lblCp = new JLabel("CP:");
		lblCp.setFont(new Font("Lucida Grande", Font.PLAIN, 10));
		panel.add(lblCp);
		
		textField_cp = new JTextField();
		panel.add(textField_cp);
		textField_cp.setColumns(8);
		
		JLabel lblPoblacin = new JLabel("Población:");
		lblPoblacin.setFont(new Font("Lucida Grande", Font.PLAIN, 10));
		panel.add(lblPoblacin);
		
		textField_poblacion = new JTextField();
		panel.add(textField_poblacion);
		textField_poblacion.setColumns(8);
		
		JLabel lblProvincia = new JLabel("Provincia:");
		lblProvincia.setFont(new Font("Lucida Grande", Font.PLAIN, 10));
		panel.add(lblProvincia);
		
		textField_provincia = new JTextField();
		panel.add(textField_provincia);
		textField_provincia.setColumns(8);
		
		JLabel lblPais = new JLabel("Pais:");
		lblPais.setFont(new Font("Lucida Grande", Font.PLAIN, 10));
		panel.add(lblPais);
		
		textField_pais = new JTextField();
		panel.add(textField_pais);
		textField_pais.setColumns(8);
		frame.getContentPane().setLayout(groupLayout);
	}
	
	/**
	 * Metodo que pinta la tabla con la lista de clientes almacenados en la BD.
	 * @throws SQLException
	 */
	private void pintarTabla() throws SQLException {
		table.setModel(new DefaultTableModel(
				new Object[][] {
				},
				new String[] {
						"Id","DNI","Nombre","Apellidos"
				}
				
				));
		
		ArrayList<Cliente> lista = new ArrayList<Cliente>();
		lista = (ArrayList<Cliente>) DaoCliente.getInstance().obtenerLista(); 		

		
		for(Cliente c : lista) {
			
			Object[] fila = new Object[4];
			
			fila[0] = c.getId();
			fila[1] = c.getDni();
			fila[2] = c.getNombre();
			fila[3] = c.getApellidos();
			
			((DefaultTableModel) table.getModel()).addRow(fila); 

			
		}

	}
	
	/**
	 * Metodo para limpiar los campos del formulario una vez termina la operación de insertar o actualizar
	 */
	private void limpiarCampos() {
		
		textField_dni.setText(null);
		textField_nombre.setText(null);
		textField_apellidos.setText(null);
		textField_nombreVia.setText(null);
		textField_numero.setText("0");
		textField_piso.setText("0");
		textField_puerta.setText(null);
		textField_cp.setText(null);
		textField_provincia.setText(null);
		textField_poblacion.setText(null);
		textField_pais.setText(null);
		comboTipovia.setSelectedIndex(0);
		
		
	}
	
	private void guardado() {
		//System.out.println("Boton Pulsado");
		//System.out.println(textField_dni.getText());
	
		if(textField_dni.getText().length() == 0 || textField_nombre.getText().length() == 0) {
			
			JOptionPane.showMessageDialog(null, "No se puede insertar sin DNI y Nombre");
			System.out.println(comboTipovia.getSelectedIndex());

			
		}else{

			cliente.setDni(textField_dni.getText());
			cliente.setNombre(textField_nombre.getText());
			cliente.setApellidos(textField_apellidos.getText());
			cliente.setNombreVia(textField_nombreVia.getText());
			cliente.setNumero(Integer.parseInt(textField_numero.getText()));
			cliente.setPiso(Integer.parseInt(textField_piso.getText()));
			cliente.setPuerta(textField_puerta.getText());
			cliente.setCp(textField_cp.getText());
			cliente.setProvincia(textField_provincia.getText());
			cliente.setPoblacion(textField_poblacion.getText());
			cliente.setPais(textField_pais.getText());
			cliente.setTipoVia(comboTipovia.getSelectedIndex());
		
		
		try {
			//JOptionPane.showMessageDialog(null, cliente.getId());

			
			if(cliente.getId() > 0 ) {
			
				cliente.update();						
			}else {
				cliente.insertar();
			}
			
			pintarTabla();
			limpiarCampos();
		
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		
		}
	}
	
	
	/**
	 * Metodo que realizar la acción de borrado del botón de la interfaz
	 */
	public void borrado() {
		DefaultTableModel tm = (DefaultTableModel) table.getModel();
		String dato=String.valueOf(tm.getValueAt(table.getSelectedRow(),0));
		
		
		if(cliente.getId() > 0 ) {
		try {
			
			cliente.delete(Integer.parseInt(dato));
			pintarTabla();
			limpiarCampos();
			
			
		} catch (NumberFormatException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		}
	}
	
	
	/**
	 * Metodo encargado de llenar los campos del formulario según la petición de un cliente en la tabla de la interfaz.
	 */
	
	public void llenarCampos() {
		DefaultTableModel tm = (DefaultTableModel) table.getModel();
		String dato=String.valueOf(tm.getValueAt(table.getSelectedRow(),0));
		//JOptionPane.showMessageDialog(null, dato);

		try {
			cliente = DaoCliente.getInstance().obtenerPorId(Integer.parseInt(dato));
			
			textField_dni.setText(cliente.getDni());
			textField_nombre.setText(cliente.getNombre());
			textField_apellidos.setText(cliente.getApellidos());
			textField_nombreVia.setText(cliente.getNombreVia());
			textField_numero.setText(String.valueOf(cliente.getNumero()));
			textField_piso.setText(String.valueOf(cliente.getPiso()));
			textField_puerta.setText(cliente.getPuerta());
			textField_cp.setText(cliente.getCp());
			textField_provincia.setText(cliente.getProvincia());
			textField_poblacion.setText(cliente.getPoblacion());
			textField_pais.setText(cliente.getPais());
			comboTipovia.setSelectedIndex(cliente.getTipoVia());
			

			
			
		} catch (NumberFormatException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
	}
	
	
}
